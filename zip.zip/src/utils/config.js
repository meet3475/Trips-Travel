const BASE_URL = "https://trips-travel-server.vercel.app/api";
// const BASE_URL = "http://localhost:3050/api";
//
export default BASE_URL;
