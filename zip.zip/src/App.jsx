import Layout from "./components/Layout/Layout";
import './App.css'
function App() {

  return (
    
    <Layout />
  )
}

export default App
